<?php
echo "<h1>Welcome SWE40006 Assignment3 Task 3.3</h1>";
echo "<p>This is my PHP app deployed from VS Code to Azure.</p>";
echo "<p>My name is Daehyeon Kim, Student ID: 104838522.</p>";
?>
